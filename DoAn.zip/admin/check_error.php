<?php if(isset($_GET['error'])){ ?>
		<p  style="color: red; ">
		<?php echo $_GET['error']; ?>
		</p>
	<?php } ?>