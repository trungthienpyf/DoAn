<link rel="stylesheet" href="assets/css/footer.css">

<footer>
    <div class="footer">
        <table class="tbf">
            <tr>
                <td>
                    <div class="footer_logo">
                        <label for="" class="logo">
                            <h2>Logo</h2>
                        </label>
                    </div>
                </td>
                <td>
                    <div>
                        <div class="footer_001">
                            <h3>Liên hệ</h3>
                            <p>abcdefghik@gmail.com</p>
                            <p>(+84) 0936 652 952</p>
                        </div>
                        <div class="footer_001">
                            <h3>Công ty</h3>
                            <p>Tuyển dụng</p>
                            <p>Hợp tác</p>
                        </div>
                        <div class="footer_001">
                            <h3>Hỗ trợ</h3>
                            <p>FAQs</p>
                            <p>Bảo mật thông tin</p>
                            <p>Chính sách chung</p>
                            <p>Tra cứu đơn hàng</p>
                        </div>
                    </div>
                </td>
            </tr>
        </table>
    </div>
</footer>