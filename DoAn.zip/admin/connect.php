<?php

$connect=mysqli_connect('localhost','root','','do_an');
mysqli_set_charset($connect,'utf8');